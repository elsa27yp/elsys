/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [iduser]
      ,[nombre]
      ,[telefono]
      ,[usuario]
      ,[pass]
      ,[rol]
      ,[empresa]
  FROM [bdlogin].[dbo].[usuariose]


  Create Procedure IngresarUsuario
  @usuario nvarchar(50), 
  @pass nvarchar(50)
As
Begin
    Insert Into Login
    (
        usuario,
        pass
    )
    Values
    (
        @usuario,
        ENCRYPTBYPASSPHRASE('pass', @pass)
    )
End
Go


  Create Procedure usuarios
    @nombre nvarchar(50),
	@telefono nvarchar(50),
	@usuario nvarchar(50),
    @Pass nvarchar(50),
	@rol nvarchar(50),
	@empresa nvarchar(50),
    @Result bit Output
As
    Declare @passEncode As nvarchar(300)
    Declare @passDecode As nvarchar(50)
Begin
    Select @passEncode = pass From bdlogin Where usuario = @usuario
    Set @passDecode = DECRYPTBYPASSPHRASE('pass', @passEncode)
End
 
Begin
    If @passDecode = @pass
        Set @Result = 1
    Else
        Set @Result = 0
End
 
Go